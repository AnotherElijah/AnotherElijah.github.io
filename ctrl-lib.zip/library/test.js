(function(){
  return(
    '<script>console.log(\'SCRIPT WORKED\')</script>'
  )

})
